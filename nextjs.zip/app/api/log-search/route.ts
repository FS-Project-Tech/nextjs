import { NextResponse } from "next/server";

export async function POST(req:Request){
  const { term } = await req.json();

  await fetch(process.env.NEXT_PUBLIC_MEILI_URL+"/indexes/search_logs/documents",{
    method:"POST",
    headers:{
      "Authorization":"Bearer "+process.env.MEILI_ADMIN_KEY,
      "Content-Type":"application/json"
    },
    body: JSON.stringify([{ term, time: Date.now() }])
  });

  return NextResponse.json({ok:true});
}
