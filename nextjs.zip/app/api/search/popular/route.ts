import { NextResponse } from "next/server";

// You can replace this with actual analytics data
const POPULAR_SEARCHES = [
  "wheelchair",
  "hospital bed",
  "walking frame",
  "continence care",
  "mobility aids",
  "medical supplies",
  "rehabilitation equipment",
  "elderly care",
];

export async function GET() {
  try {
    // In production, fetch from analytics or database
    return NextResponse.json({
      searches: POPULAR_SEARCHES,
    });
  } catch (e: any) {
    return NextResponse.json({ searches: [] });
  }
}