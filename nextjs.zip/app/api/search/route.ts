import { NextRequest, NextResponse } from "next/server";
import { MeiliSearch } from "meilisearch";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const q = searchParams.get("q") || "";
    const cat = searchParams.get("cat");
    const brand = searchParams.get("brand");
    const minPrice = searchParams.get("minPrice");
    const maxPrice = searchParams.get("maxPrice");
    const page = parseInt(searchParams.get("page") || "1");
    const perPage = Math.min(parseInt(searchParams.get("perPage") || "24"), 100);

    const client = new MeiliSearch({
      host: process.env.NEXT_PUBLIC_MEILI_URL!,
      apiKey: process.env.NEXT_PUBLIC_MEILI_SEARCH_KEY!,
    });

    let filters: string[] = [];
    if (cat) filters.push(`categories = "${cat}"`);
    if (brand) filters.push(`brand = "${brand}"`);
    if (minPrice) filters.push(`price >= ${minPrice}`);
    if (maxPrice) filters.push(`price <= ${maxPrice}`);

    const index = client.index("products");
    const res = await index.search(q, {
      limit: perPage,
      offset: (page - 1) * perPage,
      facets: ["categories", "brand", "price"],
      filter: filters.length ? filters.join(" AND ") : undefined,
    });

    return NextResponse.json({
      hits: res.hits,
      facetDistribution: res.facetDistribution,
      total: res.estimatedTotalHits || 0,
      page,
      perPage,
      totalPages: Math.ceil((res.estimatedTotalHits || 0) / perPage),
    });
  } catch (e: any) {
    console.error("MEILI SEARCH FAILED:", e);
    return NextResponse.json({
      hits: [],
      facetDistribution: {},
      total: 0,
      page: 1,
      perPage: 24,
      totalPages: 0,
    });
  }
}