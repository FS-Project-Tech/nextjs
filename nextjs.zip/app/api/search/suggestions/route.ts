import { NextRequest, NextResponse } from "next/server";
import { MeiliSearch } from "meilisearch";
import wcAPI from "@/lib/woocommerce";
import { cached, CACHE_TTL } from "@/lib/cache";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const q = searchParams.get("q") || "";

    if (!q || q.length < 2) {
      return NextResponse.json({ suggestions: [], total: 0 });
    }

    // Cache key for suggestions (short TTL for real-time feel)
    const cacheKey = `search:suggestions:${q.toLowerCase().trim()}`;

    // Use cached response if available (30 seconds TTL)
    const cachedResult = await cached(
      cacheKey,
      async () => {
        const client = new MeiliSearch({
          host: process.env.NEXT_PUBLIC_MEILI_URL!,
          apiKey: process.env.NEXT_PUBLIC_MEILI_SEARCH_KEY!,
        });

        const suggestions: any[] = [];
        const maxResults = 10;

        // Run all searches in parallel for speed
        const [productsRes, categoriesRes, brandsRes] = await Promise.allSettled([
          // Products search (fast - MeiliSearch)
          (async () => {
            try {
              const productsIndex = client.index("products");
              return await productsIndex.search(q, {
                limit: 6,
                attributesToRetrieve: [
                  "id",
                  "name",
                  "slug",
                  "price",
                  "image",
                  "sku",
                  "regular_price",
                  "sale_price",
                ],
              });
            } catch (e) {
              console.error("Product search error:", e);
              return null;
            }
          })(),

          // Categories search (with timeout)
          (async () => {
            try {
              return await Promise.race([
                wcAPI.get("/products/categories", {
                  params: {
                    search: q,
                    per_page: 3,
                    hide_empty: true,
                    _fields: "id,name,slug,image",
                  },
                  timeout: 2000, // Reduced timeout
                }),
                new Promise((_, reject) =>
                  setTimeout(() => reject(new Error("Timeout")), 2000)
                ),
              ]);
            } catch (e) {
              return null;
            }
          })(),

          // Brands search (optimized - try taxonomy first, fallback to attributes)
          (async () => {
            try {
              // Try brand taxonomy first (faster)
              const apiUrl = process.env.WC_API_URL || "";
              if (apiUrl) {
                const url = new URL(apiUrl);
                const wpBase = `${url.protocol}//${url.host}/wp-json/wp/v2`;

                try {
                  const brandsRes = await Promise.race([
                    fetch(
                      `${wpBase}/product_brand?search=${encodeURIComponent(q)}&per_page=3&hide_empty=true&_fields=id,name,slug`,
                      { signal: AbortSignal.timeout(1500) }
                    ),
                    new Promise((_, reject) =>
                      setTimeout(() => reject(new Error("Timeout")), 1500)
                    ),
                  ]);

                  if (brandsRes && (brandsRes as Response).ok) {
                    const brandsData = await (brandsRes as Response).json();
                    return Array.isArray(brandsData) ? brandsData : [];
                  }
                } catch {
                  // Fallback to product attributes (slower but works)
                }
              }

              // Fallback: Extract from product attributes (limit to 10 products for speed)
              const productsRes = await Promise.race([
                wcAPI.get("/products", {
                  params: {
                    search: q,
                    per_page: 10, // Reduced from 50 to 10
                    status: "publish",
                    _fields: "id,attributes,images",
                  },
                  timeout: 2000,
                }),
                new Promise((_, reject) =>
                  setTimeout(() => reject(new Error("Timeout")), 2000)
                ),
              ]);

              if (productsRes && (productsRes as any).data) {
                const products = Array.isArray((productsRes as any).data)
                  ? (productsRes as any).data
                  : [];
                const brandSet = new Set<string>();
                const brandMap = new Map<
                  string,
                  { name: string; slug: string; image?: string }
                >();

                products.forEach((product: any) => {
                  const brandAttr = product.attributes?.find(
                    (attr: any) =>
                      attr.name?.toLowerCase() === "brand" ||
                      attr.slug === "pa_brand"
                  );

                  if (brandAttr?.options?.[0]) {
                    const brandName = brandAttr.options[0];
                    if (!brandSet.has(brandName.toLowerCase())) {
                      brandSet.add(brandName.toLowerCase());
                      brandMap.set(brandName.toLowerCase(), {
                        name: brandName,
                        slug: brandName.toLowerCase().replace(/\s+/g, "-"),
                        image: product.images?.[0]?.src,
                      });
                    }
                  }
                });

                return Array.from(brandMap.values()).slice(0, 3);
              }

              return [];
            } catch (e) {
              return [];
            }
          })(),
        ]);

        // Process products
        if (productsRes.status === "fulfilled" && productsRes.value) {
          const products = productsRes.value.hits || [];
          products.forEach((hit: any) => {
            const price = hit.price || hit.sale_price || hit.regular_price || 0;
            const gst = price * 0.1;
            const priceWithGST = price + gst;

            suggestions.push({
              id: hit.id,
              name: hit.name || hit.title,
              slug: hit.slug,
              price: parseFloat(price),
              priceWithGST: parseFloat(priceWithGST.toFixed(2)),
              gst: parseFloat(gst.toFixed(2)),
              sku: hit.sku || "",
              image: hit.image,
              type: "product",
            });
          });
        }

        // Process categories
        if (
          categoriesRes.status === "fulfilled" &&
          categoriesRes.value?.data
        ) {
          const categories = Array.isArray(categoriesRes.value.data)
            ? categoriesRes.value.data
            : [];
          categories.forEach((cat: any) => {
            suggestions.push({
              id: cat.id,
              name: cat.name,
              slug: cat.slug,
              image: cat.image?.src || null,
              type: "category",
            });
          });
        }

        // Process brands
        if (brandsRes.status === "fulfilled" && brandsRes.value) {
          const brands = Array.isArray(brandsRes.value)
            ? brandsRes.value
            : [];
          brands.forEach((brand: any) => {
            suggestions.push({
              id: brand.id || `brand-${brand.slug}`,
              name: brand.name,
              slug: brand.slug,
              image: brand.image || null,
              type: "brand",
            });
          });
        }

        // Sort suggestions: products first, then categories, then brands
        const sortedSuggestions = [
          ...suggestions.filter((s) => s.type === "product"),
          ...suggestions.filter((s) => s.type === "category"),
          ...suggestions.filter((s) => s.type === "brand"),
        ].slice(0, maxResults);

        // Get total count (quick query, no data)
        let total = 0;
        try {
          const productsIndex = client.index("products");
          const countRes = await productsIndex.search(q, { limit: 0 });
          total = countRes.estimatedTotalHits || 0;
        } catch {
          // Silent fail
        }

        return {
          suggestions: sortedSuggestions,
          total,
        };
      },
      {
        ttl: 30, // 30 seconds cache (short for real-time feel)
        tags: ["search", "suggestions"],
      }
    );

    return NextResponse.json(cachedResult, {
      headers: {
        "Cache-Control": "public, s-maxage=30, stale-while-revalidate=60",
      },
    });
  } catch (e: any) {
    console.error("Search suggestions error:", e);
    return NextResponse.json({ suggestions: [], total: 0 });
  }
}