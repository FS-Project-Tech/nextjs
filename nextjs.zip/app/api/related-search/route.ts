import { MeiliSearch } from "meilisearch";
import { NextResponse } from "next/server";

export async function GET(req:Request){
  const { searchParams } = new URL(req.url);
  const q = searchParams.get("q")||"";

  const client = new MeiliSearch({
    host: process.env.NEXT_PUBLIC_MEILI_URL!,
    apiKey: process.env.MEILI_ADMIN_KEY!
  });

  const index = client.index("search_logs");
  const res = await index.search(q,{limit:5});

  return NextResponse.json(res.hits);
}
