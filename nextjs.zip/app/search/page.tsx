"use client";
import { useSearchParams, useRouter } from "next/navigation";
import { useEffect, useState, useCallback } from "react";
import Link from "next/link";
import ProductCard from "@/components/ProductCard";

interface SearchResult {
  id: number;
  name: string;
  slug: string;
  price: number;
  image?: string;
  title?: string;
}

export default function SearchPage() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const q = searchParams.get("q") || "";
  const cat = searchParams.get("cat");
  const brand = searchParams.get("brand");
  const minPrice = searchParams.get("minPrice");
  const maxPrice = searchParams.get("maxPrice");
  const page = parseInt(searchParams.get("page") || "1");

  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [priceRange, setPriceRange] = useState({ min: 0, max: 10000 });
  const [selectedMinPrice, setSelectedMinPrice] = useState(minPrice || "");
  const [selectedMaxPrice, setSelectedMaxPrice] = useState(maxPrice || "");

  // Build search URL
  const buildSearchUrl = useCallback(
    (params: Record<string, string | null>) => {
      const newParams = new URLSearchParams();
      if (q) newParams.set("q", q);
      Object.entries(params).forEach(([key, value]) => {
        if (value) newParams.set(key, value);
      });
      return `/search?${newParams.toString()}`;
    },
    [q]
  );

  // Fetch search results
  useEffect(() => {
    if (!q) {
      setLoading(false);
      return;
    }

    setLoading(true);
    let url = `/api/search?q=${encodeURIComponent(q)}&page=${page}&perPage=24`;
    if (cat) url += `&cat=${encodeURIComponent(cat)}`;
    if (brand) url += `&brand=${encodeURIComponent(brand)}`;
    if (minPrice) url += `&minPrice=${minPrice}`;
    if (maxPrice) url += `&maxPrice=${maxPrice}`;

    fetch(url)
      .then((r) => r.json())
      .then((data) => {
        setData(data);
        // Extract price range from facets
        if (data.facetDistribution?.price) {
          const prices = Object.keys(data.facetDistribution.price).map(Number);
          if (prices.length > 0) {
            setPriceRange({
              min: Math.min(...prices),
              max: Math.max(...prices),
            });
          }
        }
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  }, [q, cat, brand, minPrice, maxPrice, page]);

  const handleFilterChange = (key: string, value: string | null) => {
    const params: Record<string, string | null> = {
      cat: key === "cat" ? value : cat,
      brand: key === "brand" ? value : brand,
      minPrice: key === "minPrice" ? value : minPrice,
      maxPrice: key === "maxPrice" ? value : maxPrice,
    };
    router.push(buildSearchUrl(params));
  };

  const handlePriceFilter = () => {
    router.push(
      buildSearchUrl({
        cat,
        brand,
        minPrice: selectedMinPrice || null,
        maxPrice: selectedMaxPrice || null,
      })
    );
  };

  const clearFilters = () => {
    router.push(buildSearchUrl({ cat: null, brand: null, minPrice: null, maxPrice: null }));
    setSelectedMinPrice("");
    setSelectedMaxPrice("");
  };

  const hasActiveFilters = cat || brand || minPrice || maxPrice;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="mx-auto w-full sm:w-[85vw] px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">
            {q ? `Search results for "${q}"` : "Search"}
          </h1>
          {data && (
            <p className="text-sm text-gray-600 mt-1">
              {data.total} {data.total === 1 ? "result" : "results"} found
            </p>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Left Sidebar - Filters */}
          <aside className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 sticky top-4">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-gray-900">Filters</h2>
                {hasActiveFilters && (
                  <button
                    onClick={clearFilters}
                    className="text-sm text-teal-600 hover:text-teal-700"
                  >
                    Clear all
                  </button>
                )}
              </div>

              {/* Price Range Filter */}
              <div className="mb-6 pb-6 border-b">
                <h3 className="text-sm font-medium text-gray-900 mb-3">Price Range</h3>
                <div className="space-y-3">
                  <div className="flex gap-2">
                    <input
                      type="number"
                      placeholder="Min"
                      value={selectedMinPrice}
                      onChange={(e) => setSelectedMinPrice(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
                      min={priceRange.min}
                      max={priceRange.max}
                    />
                    <input
                      type="number"
                      placeholder="Max"
                      value={selectedMaxPrice}
                      onChange={(e) => setSelectedMaxPrice(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
                      min={priceRange.min}
                      max={priceRange.max}
                    />
                  </div>
                  <button
                    onClick={handlePriceFilter}
                    className="w-full px-4 py-2 bg-teal-600 text-white rounded-md hover:bg-teal-700 text-sm font-medium"
                  >
                    Apply
                  </button>
                  <div className="text-xs text-gray-500">
                    Range: ${priceRange.min} - ${priceRange.max}
                  </div>
                </div>
              </div>

              {/* Category Filter */}
              {data?.facetDistribution?.categories && (
                <div className="mb-6 pb-6 border-b">
                  <h3 className="text-sm font-medium text-gray-900 mb-3">Categories</h3>
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {Object.entries(data.facetDistribution.categories)
                      .sort(([, a]: any, [, b]: any) => b - a)
                      .map(([category, count]: [string, any]) => (
                        <label
                          key={category}
                          className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-2 rounded"
                        >
                          <input
                            type="checkbox"
                            checked={cat === category}
                            onChange={(e) =>
                              handleFilterChange("cat", e.target.checked ? category : null)
                            }
                            className="rounded border-gray-300 text-teal-600 focus:ring-teal-500"
                          />
                          <span className="text-sm text-gray-700 flex-1">{category}</span>
                          <span className="text-xs text-gray-500">({count})</span>
                        </label>
                      ))}
                  </div>
                </div>
              )}

              {/* Brand Filter */}
              {data?.facetDistribution?.brand && (
                <div className="mb-6">
                  <h3 className="text-sm font-medium text-gray-900 mb-3">Brands</h3>
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {Object.entries(data.facetDistribution.brand)
                      .sort(([, a]: any, [, b]: any) => b - a)
                      .map(([brandName, count]: [string, any]) => (
                        <label
                          key={brandName}
                          className="flex items-center gap-2 cursor-pointer hover:bg-gray-50 p-2 rounded"
                        >
                          <input
                            type="checkbox"
                            checked={brand === brandName}
                            onChange={(e) =>
                              handleFilterChange("brand", e.target.checked ? brandName : null)
                            }
                            className="rounded border-gray-300 text-teal-600 focus:ring-teal-500"
                          />
                          <span className="text-sm text-gray-700 flex-1">{brandName}</span>
                          <span className="text-xs text-gray-500">({count})</span>
                        </label>
                      ))}
                  </div>
                </div>
              )}
            </div>
          </aside>

          {/* Main Content - Results */}
          <div className="lg:col-span-3">
            {loading ? (
              <div className="flex items-center justify-center py-12">
                <div className="h-8 w-8 animate-spin rounded-full border-2 border-gray-300 border-t-teal-600" />
              </div>
            ) : !q ? (
              <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-12 text-center">
                <p className="text-gray-500">Enter a search query to see results</p>
              </div>
            ) : data?.hits?.length === 0 ? (
              <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-12 text-center">
                <p className="text-gray-500 mb-4">No results found for "{q}"</p>
                <button
                  onClick={clearFilters}
                  className="text-teal-600 hover:text-teal-700 text-sm font-medium"
                >
                  Clear filters to see more results
                </button>
              </div>
            ) : (
              <>
                {/* Results Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
                  {data?.hits?.map((product: any) => (
                    <ProductCard
                      key={product.id}
                      id={product.id}
                      slug={product.slug}
                      name={product.name || product.title}
                      sku={product.sku || ""}
                      price={product.price}
                      sale_price={product.sale_price}
                      regular_price={product.regular_price}
                      on_sale={product.on_sale}
                      tax_class={product.tax_class}
                      tax_status={product.tax_status}
                      average_rating={product.average_rating}
                      rating_count={product.rating_count}
                      imageUrl={product.image}
                      imageAlt={product.name || product.title}
                    />
                  ))}
                </div>

                {/* Pagination */}
                {data && data.totalPages > 1 && (
                  <div className="flex items-center justify-center gap-2">
                    <button
                      onClick={() =>
                        router.push(
                          buildSearchUrl({
                            cat,
                            brand,
                            minPrice,
                            maxPrice,
                            page: (page - 1).toString(),
                          })
                        )
                      }
                      disabled={page === 1}
                      className="px-4 py-2 border border-gray-300 rounded-md disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50"
                    >
                      Previous
                    </button>
                    <span className="text-sm text-gray-600">
                      Page {page} of {data.totalPages}
                    </span>
                    <button
                      onClick={() =>
                        router.push(
                          buildSearchUrl({
                            cat,
                            brand,
                            minPrice,
                            maxPrice,
                            page: (page + 1).toString(),
                          })
                        )
                      }
                      disabled={page >= data.totalPages}
                      className="px-4 py-2 border border-gray-300 rounded-md disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50"
                    >
                      Next
                    </button>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}