"use client";
import { useEffect, useState, useRef, useCallback } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import Image from "next/image";

interface SearchBarProps {
  className?: string;
}

interface SearchSuggestion {
  id: number | string;
  name: string;
  slug: string;
  price?: number;
  priceWithGST?: number;
  gst?: number;
  sku?: string;
  image?: string | null;
  type?: "product" | "category" | "brand";
}

const RECENT_SEARCHES_KEY = "recent_searches";
const MAX_RECENT_SEARCHES = 5;

export default function SearchBox({ className = "" }: SearchBarProps) {
  const [q, setQ] = useState("");
  const [suggestions, setSuggestions] = useState<SearchSuggestion[]>([]);
  const [popularSearches, setPopularSearches] = useState<string[]>([]);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const [showDropdown, setShowDropdown] = useState(false);
  const [loading, setLoading] = useState(false);
  const [resultCount, setResultCount] = useState<number | null>(null);
  const router = useRouter();
  const searchRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const debounceTimer = useRef<NodeJS.Timeout>();

  // Load recent searches from localStorage
  useEffect(() => {
    try {
      const stored = localStorage.getItem(RECENT_SEARCHES_KEY);
      if (stored) {
        setRecentSearches(JSON.parse(stored));
      }
    } catch {
      // Silent fail
    }
  }, []);

  // Load popular searches
  useEffect(() => {
    const fetchPopular = async () => {
      try {
        const res = await fetch("/api/search/popular");
        const data = await res.json();
        setPopularSearches(data.searches || []);
      } catch {
        // Silent fail
      }
    };
    fetchPopular();
  }, []);

  // Debounced search suggestions with request cancellation
useEffect(() => {
  if (debounceTimer.current) {
    clearTimeout(debounceTimer.current);
  }

  if (!q || q.length < 2) {
    setSuggestions([]);
    setResultCount(null);
    setShowDropdown(false);
    return;
  }

  setLoading(true);
  
  // AbortController for request cancellation
  const abortController = new AbortController();
  
  debounceTimer.current = setTimeout(async () => {
    try {
      const res = await fetch(`/api/search/suggestions?q=${encodeURIComponent(q)}`, {
        signal: abortController.signal,
        // Add cache headers for better performance
        next: { revalidate: 30 },
      });
      
      if (res.ok) {
        const data = await res.json();
        setSuggestions(data.suggestions || []);
        setResultCount(data.total || null);
        setShowDropdown(true);
      }
    } catch (error: any) {
      // Ignore abort errors
      if (error.name !== "AbortError") {
        console.error("Search error:", error);
        setSuggestions([]);
      }
    } finally {
      setLoading(false);
    }
  }, 300); // Keep 300ms debounce

  return () => {
    if (debounceTimer.current) {
      clearTimeout(debounceTimer.current);
    }
    // Cancel ongoing request when query changes
    abortController.abort();
  };
}, [q]);

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowDropdown(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Save to recent searches
  const saveRecentSearch = useCallback((query: string) => {
    if (!query.trim()) return;

    try {
      const current = JSON.parse(
        localStorage.getItem(RECENT_SEARCHES_KEY) || "[]"
      ) as string[];
      const updated = [
        query.trim(),
        ...current.filter((s) => s.toLowerCase() !== query.trim().toLowerCase()),
      ].slice(0, MAX_RECENT_SEARCHES);
      localStorage.setItem(RECENT_SEARCHES_KEY, JSON.stringify(updated));
      setRecentSearches(updated);
    } catch {
      // Silent fail
    }
  }, []);

  const handleSearch = useCallback(
    (query: string) => {
      if (!query.trim()) return;
      saveRecentSearch(query);
      setShowDropdown(false);
      router.push(`/search?q=${encodeURIComponent(query)}`);
    },
    [router, saveRecentSearch]
  );

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && q.trim()) {
      handleSearch(q);
    } else if (e.key === "Escape") {
      setShowDropdown(false);
      inputRef.current?.blur();
    }
  };

  const handleSuggestionClick = (suggestion: SearchSuggestion) => {
    saveRecentSearch(suggestion.name);
    setShowDropdown(false);
    if (suggestion.type === "product") {
      router.push(`/products/${suggestion.slug}`);
    } else if (suggestion.type === "category") {
      router.push(`/product-category/${suggestion.slug}`);
    } else if (suggestion.type === "brand") {
      router.push(`/search?q=${encodeURIComponent(suggestion.name)}&brand=${encodeURIComponent(suggestion.slug)}`);
    } else {
      router.push(`/search?q=${encodeURIComponent(suggestion.name)}`);
    }
  };

  const handleRecentSearchClick = (query: string) => {
    setQ(query);
    handleSearch(query);
  };

  const clearRecentSearches = () => {
    localStorage.removeItem(RECENT_SEARCHES_KEY);
    setRecentSearches([]);
  };

  return (
    <div ref={searchRef} className={`relative ${className}`}>
      <div className="relative">
        <input
          ref={inputRef}
          type="text"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          onFocus={() => {
            if (q.length >= 2 || recentSearches.length > 0 || popularSearches.length > 0) {
              setShowDropdown(true);
            }
          }}
          onKeyDown={handleKeyDown}
          className="w-full rounded-xl border border-gray-300 px-4 py-3 pr-12 focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent"
          placeholder="Search products, brands, categories..."
        />
        <button
          onClick={() => q.trim() && handleSearch(q)}
          className="absolute right-2 top-1/2 -translate-y-1/2 rounded-lg bg-teal-600 px-4 py-2 text-white hover:bg-teal-700 transition-colors"
          aria-label="Search"
        >
          <svg
            viewBox="0 0 24 24"
            className="h-5 w-5"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
          >
            <circle cx="11" cy="11" r="8" />
            <path d="M21 21l-4.35-4.35" />
          </svg>
        </button>
        {loading && (
          <div className="absolute right-16 top-1/2 -translate-y-1/2">
            <div className="h-5 w-5 animate-spin rounded-full border-2 border-gray-300 border-t-teal-600" />
          </div>
        )}
      </div>

      {/* Dropdown */}
      {showDropdown && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-lg shadow-2xl border border-gray-200 z-50 max-h-[600px] overflow-y-auto">
          {/* Search Suggestions */}
          {q.length >= 2 && (
            <>
              {suggestions.length > 0 ? (
                <div className="p-4 border-b">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-sm font-semibold text-gray-900">
                      Suggestions ({suggestions.length})
                    </h3>
                    {resultCount !== null && (
                      <span className="text-xs text-gray-500">
                        {resultCount} total results
                      </span>
                    )}
                  </div>
                  <div className="space-y-2">
                    {suggestions.slice(0, 10).map((suggestion) => (
                      <button
                        key={`${suggestion.type}-${suggestion.id}`}
                        onClick={() => handleSuggestionClick(suggestion)}
                        className="w-full text-left p-3 rounded-lg hover:bg-gray-50 border border-transparent hover:border-gray-200 transition-all group"
                      >
                        <div className="flex items-start gap-4">
                          {/* Image */}
                          <div className="flex-shrink-0">
                            {suggestion.image ? (
                              <div className="relative w-16 h-16 rounded-md overflow-hidden bg-gray-100">
                                <Image
                                  src={suggestion.image}
                                  alt={suggestion.name}
                                  fill
                                  className="object-cover"
                                  sizes="64px"
                                />
                              </div>
                            ) : (
                              <div className="w-16 h-16 rounded-md bg-gray-100 flex items-center justify-center">
                                <svg
                                  viewBox="0 0 24 24"
                                  className="h-8 w-8 text-gray-400"
                                  fill="none"
                                  stroke="currentColor"
                                  strokeWidth="2"
                                >
                                  {suggestion.type === "category" ? (
                                    <rect x="3" y="3" width="18" height="18" rx="2" />
                                  ) : suggestion.type === "brand" ? (
                                    <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5" />
                                  ) : (
                                    <rect x="3" y="3" width="18" height="18" rx="2" />
                                  )}
                                </svg>
                              </div>
                            )}
                          </div>

                          {/* Details */}
                          <div className="flex-1 min-w-0">
                            {/* Name */}
                            <div className="font-semibold text-gray-900 group-hover:text-teal-600 transition-colors mb-1">
                              {suggestion.name}
                            </div>

                            {/* Type Badge */}
                            <div className="flex items-center gap-2 mb-2">
                              <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-teal-100 text-teal-800 capitalize">
                                {suggestion.type}
                              </span>
                            </div>

                            {/* Product Details: Price, SKU, GST */}
                            {suggestion.type === "product" && (
                              <div className="space-y-1 text-sm">
                                {/* Price and GST */}
                                <div className="flex items-center gap-3">
                                  {suggestion.price !== undefined && (
                                    <div className="flex items-center gap-2">
                                      <span className="text-gray-600">Price:</span>
                                      <span className="font-semibold text-gray-900">
                                        ${suggestion.price.toFixed(2)}
                                      </span>
                                    </div>
                                  )}
                                  {suggestion.gst !== undefined && (
                                    <div className="flex items-center gap-2">
                                      <span className="text-gray-600">GST:</span>
                                      <span className="font-medium text-gray-700">
                                        ${suggestion.gst.toFixed(2)}
                                      </span>
                                    </div>
                                  )}
                                  {suggestion.priceWithGST !== undefined && (
                                    <div className="flex items-center gap-2">
                                      <span className="text-gray-600">Total:</span>
                                      <span className="font-bold text-teal-600">
                                        ${suggestion.priceWithGST.toFixed(2)}
                                      </span>
                                    </div>
                                  )}
                                </div>

                                {/* SKU */}
                                {suggestion.sku && (
                                  <div className="flex items-center gap-2">
                                    <span className="text-gray-600">SKU:</span>
                                    <span className="font-mono text-xs text-gray-700 bg-gray-100 px-2 py-0.5 rounded">
                                      {suggestion.sku}
                                    </span>
                                  </div>
                                )}
                              </div>
                            )}

                            {/* Category/Brand Info */}
                            {(suggestion.type === "category" || suggestion.type === "brand") && (
                              <div className="text-xs text-gray-500 mt-1">
                                Click to view {suggestion.type === "category" ? "category" : "brand"} products
                              </div>
                            )}
                          </div>

                          {/* Arrow Icon */}
                          <div className="flex-shrink-0">
                            <svg
                              viewBox="0 0 24 24"
                              className="h-5 w-5 text-gray-400 opacity-0 group-hover:opacity-100 transition-opacity"
                              fill="none"
                              stroke="currentColor"
                              strokeWidth="2"
                            >
                              <path d="M5 12h14M12 5l7 7-7 7" />
                            </svg>
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                  {resultCount !== null && resultCount > suggestions.length && (
                    <button
                      onClick={() => handleSearch(q)}
                      className="w-full mt-3 px-3 py-2 text-sm font-medium text-teal-600 hover:bg-teal-50 rounded-md border border-teal-200"
                    >
                      View all {resultCount} results →
                    </button>
                  )}
                </div>
              ) : (
                !loading && (
                  <div className="p-4 border-b">
                    <p className="text-sm text-gray-500">No suggestions found</p>
                    <button
                      onClick={() => handleSearch(q)}
                      className="mt-2 text-sm font-medium text-teal-600 hover:text-teal-700"
                    >
                      Search for "{q}" →
                    </button>
                  </div>
                )
              )}
            </>
          )}

          {/* Recent Searches */}
          {q.length < 2 && recentSearches.length > 0 && (
            <div className="p-4 border-b">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold text-gray-900">Recent Searches</h3>
                <button
                  onClick={clearRecentSearches}
                  className="text-xs text-gray-500 hover:text-gray-700"
                  aria-label="Clear recent searches"
                >
                  Clear
                </button>
              </div>
              <div className="flex flex-wrap gap-2">
                {recentSearches.map((search, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleRecentSearchClick(search)}
                    className="px-3 py-1.5 text-sm bg-gray-100 hover:bg-gray-200 rounded-full transition-colors"
                  >
                    {search}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Popular Searches */}
          {q.length < 2 && popularSearches.length > 0 && (
            <div className="p-4">
              <h3 className="text-sm font-semibold text-gray-900 mb-3">Popular Searches</h3>
              <div className="flex flex-wrap gap-2">
                {popularSearches.map((search, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleRecentSearchClick(search)}
                    className="px-3 py-1.5 text-sm bg-teal-50 hover:bg-teal-100 text-teal-700 rounded-full transition-colors"
                  >
                    {search}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}