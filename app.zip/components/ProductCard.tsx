"use client";
 
import Image from "next/image";
import Link from "next/link";
import { memo, useState, useCallback, useMemo, type MouseEvent } from "react";
import { useCart } from "@/components/CartProvider";
import { useToast } from "@/components/ToastProvider";
import { WishlistButton } from "@/components/WishlistButton";
import { formatPriceWithLabel } from "@/lib/format-utils";
 
const TAG_COLORS: Record<string, string> = {
  empower: '#FF8000',
  new: '#069494',
};
 
function getTagColor(tag: { name?: string; slug?: string }): string {
  const key = (tag.slug ?? tag.name ?? '').toLowerCase().trim();
  return TAG_COLORS[key] ?? '#0d9488';
}
 
// ============================================================================
// Types
// ============================================================================
 
export interface ProductCardProps {
  id: number;
  slug: string;
  name: string;
  sku?: string | null;
  price: string;
  sale_price?: string;
  regular_price?: string;
  on_sale?: boolean;
  imageUrl?: string;
  imageAlt?: string;
  tax_class?: string;
  tax_status?: string;
  average_rating?: string;
  rating_count?: number;
  /** Priority loading for above-the-fold cards */
  priority?: boolean;
  /** Compact mode for smaller displays */
  compact?: boolean;
  /** Sale/discount % from backend; shown in corner badge when on sale */
  sale_percentage?: number | null;
  tags?: Array<{ id: number; name: string; slug: string }>;
}
 
interface PriceData {
  regular: number;
  current: number;
  isOnSale: boolean;
  discount: number;
  savings: string;
  formattedRegular: string;
  formattedRegularWithLabel: string;
  formattedCurrent: string;
  label: string;
  exclPrice: string | null;
  isGstFree: boolean;
}
 
interface RatingData {
  avg: number;
  count: number;
}
 
// ============================================================================
// Constants
// ============================================================================
 
const PLACEHOLDER_IMAGE = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='400' height='400' viewBox='0 0 400 400'%3E%3Crect fill='%23f3f4f6' width='400' height='400'/%3E%3Ctext x='50%25' y='50%25' dominant-baseline='middle' text-anchor='middle' fill='%239ca3af' font-family='system-ui' font-size='14'%3ENo Image%3C/text%3E%3C/svg%3E";
 
// SVG paths as constants to avoid recreation
const CART_ICON_PATH = "M3 3h2l.4 2M7 13h10l4-8H5.4M7 13l-1.5 6h12.2M7 13L5 5m2 14a1 1 0 110-2 1 1 0 010 2zm9 0a1 1 0 110-2 1 1 0 010 2z";
const STAR_ICON_PATH = "M10 15l-5.878 3.09 1.123-6.545L.49 6.91l6.564-.954L10 0l2.946 5.956 6.564.954-4.755 4.635 1.123 6.545z";
 
// ============================================================================
// Helper Functions (outside component to avoid recreation)
// ============================================================================
 
 
function calculatePriceData(
  price: string,
  salePrice?: string,
  regularPrice?: string,
  onSale?: boolean,
  taxClass?: string,
  taxStatus?: string
): PriceData {
  const regular = regularPrice ? parseFloat(regularPrice) : 0;
  const sale = salePrice ? parseFloat(salePrice) : 0;
 
  const current = sale > 0 ? sale : parseFloat(price || "0");
 
  const isOnSale =
    regular > 0 &&
    sale > 0 &&
    sale < regular;
 
  const discount = isOnSale
    ? Math.round(((regular - sale) / regular) * 100)
    : 0;
 
  const savingsAmount = isOnSale ? regular - sale : 0;
  const savings = savingsAmount > 0 ? `$${savingsAmount.toFixed(2)}` : "";
 
  let formattedPrice = `$${current.toFixed(2)}`;
  let label = "Price";
  let exclPrice: string | null = null;
  let isGstFree = false;
 
  let formattedRegularWithLabel = `$${regular.toFixed(2)}`;
  try {
    const priceInfo = formatPriceWithLabel(current, taxClass, taxStatus);
    formattedPrice = priceInfo.price;
    label = priceInfo.label || label;
    exclPrice = priceInfo.exclPrice || null;
    isGstFree = priceInfo.taxType === "gst_free";
    const regularInfo = formatPriceWithLabel(regular, taxClass, taxStatus);
    formattedRegularWithLabel =
      regularInfo.label ? `${regularInfo.label}: ${regularInfo.price}` : regularInfo.price;
  } catch {}
 
  return {
    regular,
    current,
    isOnSale,
    discount,
    savings,
    formattedRegular: `$${regular.toFixed(2)}`,
    formattedRegularWithLabel,
    formattedCurrent: formattedPrice,
    label,
    exclPrice,
    isGstFree,
  };
}
 
 
function calculateRatingData(ratingCount?: number, averageRating?: string): RatingData | null {
  const count = Number(ratingCount || 0);
  if (count <= 0) return null;
 
  const avg = parseFloat(averageRating || "0") || 0;
  const clampedAvg = Math.max(0, Math.min(5, avg));
 
  return isNaN(clampedAvg) ? null : { avg: Math.round(clampedAvg), count };
}
 
// ============================================================================
// Sub-components (memoized for performance)
// ============================================================================
 
const StarRating = memo(function StarRating({ rating }: { rating: RatingData }) {
  return (
    <div className="mt-2 flex items-center gap-1" role="img" aria-label={`Rated ${rating.avg} out of 5 stars`}>
      <div className="flex gap-0.5 text-amber-400">
        {[0, 1, 2, 3, 4].map((i) => (
          <svg
            key={i}
            className={`h-4 w-4 ${i < rating.avg ? "fill-current" : "fill-gray-200"}`}
            viewBox="0 0 20 20"
            aria-hidden="true"
          >
            <path d={STAR_ICON_PATH} />
          </svg>
        ))}
      </div>
      <span className="text-xs text-gray-600">({rating.count})</span>
    </div>
  );
});
 
const DiscountBadge = memo(function DiscountBadge({
  discount,
  saleOnly,
}: {
  discount: number;
  saleOnly?: boolean;
}) {
  const showPercent = discount > 0;
  const showSale = saleOnly && discount <= 0;
  if (!showPercent && !showSale) return null;
  return (
    <span
      className="absolute bottom-2 right-2 rounded-full bg-red-600 px-3 py-1 text-xs font-semibold text-white"
      aria-label={showPercent ? `${discount}% off` : "On sale"}
    >
      {showPercent ? `${discount}% OFF` : "Sale"}
    </span>
  );
});
 
 
const LoadingSpinner = memo(function LoadingSpinner() {
  return (
    <svg className="h-4 w-4 animate-spin" fill="none" viewBox="0 0 24 24" aria-hidden="true">
      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
    </svg>
  );
});
 
// ============================================================================
// Main Component
// ============================================================================
 
function ProductCardComponent({
  id,
  slug,
  name,
  sku,
  price,
  sale_price,
  regular_price,
  on_sale,
  imageUrl,
  imageAlt,
  tax_class,
  tax_status,
  average_rating,
  rating_count,
  priority = false,
  compact = false,
  sale_percentage: salePercentageFromBackend,
  tags,
}: ProductCardProps) {
 
  // Hooks
  const { addItem, open: openCart } = useCart();
  const { success, error: showError } = useToast();
 
  // Local state
  const [addingToCart, setAddingToCart] = useState(false);
  const [imageError, setImageError] = useState(false);
 
  // Memoized calculations
  const priceData = useMemo(
    () => calculatePriceData(price, sale_price, regular_price, on_sale, tax_class, tax_status),
    [price, sale_price, regular_price, on_sale, tax_class, tax_status]
  );
 
  const ratingData = useMemo(
    () => calculateRatingData(rating_count, average_rating),
    [rating_count, average_rating]
  );
 
  const productUrl = useMemo(() => `/products/${slug}`, [slug]);
 
  // Stable image source
  const imageSrc = useMemo(() => {
    if (imageError || !imageUrl) return PLACEHOLDER_IMAGE;
    return imageUrl;
  }, [imageUrl, imageError]);
 
  // Event handlers (useCallback for stable references)
  const handleImageError = useCallback(() => {
    setImageError(true);
  }, []);
 
  const handleAddToCart = useCallback(async () => {
    if (addingToCart) return;
 
    setAddingToCart(true);
    try {
      addItem({
        productId: id,
        name,
        slug,
        imageUrl: imageUrl || undefined,
        price: sale_price || price || "0",
        qty: 1,
        sku: sku || undefined,
        tax_class: tax_class || undefined,
        tax_status: tax_status || undefined,
      });
 
      openCart();
      success("Added to cart");
    } catch (err) {
      console.error("Cart error:", err);
      showError("Failed to add to cart");
    } finally {
      setAddingToCart(false);
    }
  }, [id, name, slug, imageUrl, price, sale_price, sku, tax_class, tax_status, addingToCart, addItem, openCart, success, showError]);
 
 
  return (
    <article
      className="flex h-full flex-col rounded-xl border border-gray-200 bg-white p-3 transition hover:shadow-md"
      style={{ contain: "layout style paint" }}
    >
      {/* Image Section */}
      <Link
        href={productUrl}
        className="relative block overflow-hidden rounded-lg bg-white"
        aria-label={`View ${name}`}
        prefetch={false}
      >
        <div className={'relative aspect-square'}>
          <Image
            src={imageSrc}
            alt={imageAlt || name}
            fill
            sizes="(max-width: 768px) 50vw, (max-width: 1200px) 33vw, 25vw"
            className="object-contain p-4"
            onError={handleImageError}
          />
 
          {/* Wishlist Button */}
          <div className="absolute top-2 left-2 z-10">
            <WishlistButton productId={id} size="sm" variant="icon" className="bg-white rounded-full shadow-sm hover:scale-110 transition" />
          </div>
          {/* Product Tags - top right */}
          {tags && tags.length > 0 && (
            <div className="absolute top-2 right-2 z-10 flex flex-col gap-1">
              {tags.map((tag) => (
                <span
                  key={tag.id}
                  className="rounded-full px-2.5 py-0.5 text-xs font-semibold text-white"
                  style={{ backgroundColor: getTagColor(tag) }}
                >
                  {tag.name}
                </span>
              ))}
            </div>
          )}
 
          {/* Discount Badge */}
          {(salePercentageFromBackend != null && salePercentageFromBackend > 0) ||
          priceData.isOnSale ||
          on_sale ? (
            <DiscountBadge
              discount={
                salePercentageFromBackend != null && salePercentageFromBackend > 0
                  ? salePercentageFromBackend
                  : priceData.discount
              }
              saleOnly={
                on_sale &&
                !priceData.isOnSale &&
                (salePercentageFromBackend == null || salePercentageFromBackend <= 0)
              }
            />
          ) : null}
        </div>
      </Link>
 
      {/* Content Section */}
      <div className="flex flex-1 flex-col pt-3">
        {/* Product Info */}
        <div className="min-h-0 flex-1 overflow-hidden text-ellipsis">
          <Link
            href={productUrl}
            className="text-sm font-medium text-gray-900 line-clamp-2 min-h-[60px]"
          >
            {name}
          </Link>
 
          <p className="mt-1 text-xs text-gray-500 min-h-[18px]">
            {sku ? `SKU: ${sku}` : "\u00A0"}
          </p>
 
 
          <div className="hidden min-h-[1.25rem] sm:block">
            {ratingData && <StarRating rating={ratingData} />}
          </div>
 
        </div>
 
        {/* Pricing */}
        <div className="space-y-1 min-h-[2.75rem] sm:min-h-[3.5rem]">
          {priceData.isOnSale && (
            <div className="flex flex-wrap items-center gap-2">
              <p className="text-sm text-gray-500 line-through">{priceData.formattedRegularWithLabel}</p>
              <span className="text-xs font-semibold text-green-600">
                Save {priceData.savings}
              </span>
            </div>
          )}
 
          <div className={priceData.isGstFree ? "text-emerald-700" : undefined}>
            <p className={`font-bold text-[16px]`}>
              {priceData.label}: {priceData.formattedCurrent}
            </p>
 
            {priceData.exclPrice && (
              <p className="hidden text-xs text-gray-600 sm:block">
                Excl. GST: {priceData.exclPrice}
              </p>
            )}
          </div>
        </div>
 
        {/* Actions */}
        <div className="mt-auto flex items-center gap-2 pt-2">
          <button
            type="button"
            onClick={handleAddToCart}
            disabled={addingToCart}
            className="flex-1 inline-flex items-center justify-center gap-2 rounded-lg bg-teal-700 px-3 py-2.5 text-sm font-semibold text-white transition-colors duration-150 hover:bg-teal-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-teal-500 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-60"
            aria-label={`Add ${name} to cart`}
            aria-busy={addingToCart}
          >
            {addingToCart ? (
              <>
                <LoadingSpinner />
                <span className="sr-only sm:not-sr-only">Adding…</span>
              </>
            ) : (
              <>
                <svg className="h-5 w-5 shrink-0" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24" aria-hidden="true">
                  <path strokeLinecap="round" strokeLinejoin="round" d={CART_ICON_PATH} />
                </svg>
                <span className="sr-only sm:not-sr-only">Add to cart</span>
              </>
            )}
          </button>
         
         
        </div>
      </div>
    </article>
  );
}
 
 
 
 
// ============================================================================
// Export with memo + custom comparison
// ============================================================================
 
function propsAreEqual(prev: ProductCardProps, next: ProductCardProps): boolean {
  // Compare only props that affect rendering
  return (
    prev.id === next.id &&
    prev.slug === next.slug &&
    prev.name === next.name &&
    prev.sku === next.sku &&
    prev.price === next.price &&
    prev.sale_price === next.sale_price &&
    prev.regular_price === next.regular_price &&
    prev.on_sale === next.on_sale &&
    prev.imageUrl === next.imageUrl &&
    prev.tax_class === next.tax_class &&
    prev.tax_status === next.tax_status &&
    prev.average_rating === next.average_rating &&
    prev.rating_count === next.rating_count &&
    prev.priority === next.priority &&
    prev.compact === next.compact &&
    prev.sale_percentage === next.sale_percentage &&
    JSON.stringify(prev.tags ?? []) === JSON.stringify(next.tags ?? [])
  );
}
 
const ProductCard = memo(ProductCardComponent, propsAreEqual);
 
export default ProductCard;